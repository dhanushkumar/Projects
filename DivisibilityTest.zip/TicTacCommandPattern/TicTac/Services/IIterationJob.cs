﻿
namespace TicTac.Calculator
{
    public interface IIterationJob
    {
        void Set(int iterations);
    }
}

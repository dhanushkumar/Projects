﻿namespace TicTac.Calculator
{
    public interface INumber
    {
        int Value { get; set; }
        string Alias { get; set; }
    }
}

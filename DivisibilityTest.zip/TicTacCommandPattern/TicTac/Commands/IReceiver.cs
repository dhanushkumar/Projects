﻿
namespace TicTac.Calculator
{
    public interface IReceiver
    {
        void WriteToConsole(INumber result);
    }
}

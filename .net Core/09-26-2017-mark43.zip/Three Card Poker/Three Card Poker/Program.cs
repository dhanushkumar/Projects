﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace Three_Card_Poker
{
    class Program
    {
        static void Main(string[] args)
        {
           
            var playerCount = Console.ReadLine();
            var numberOfPlayers = 0;
           try
            {
                numberOfPlayers = Convert.ToInt32(playerCount);
            }
            catch
            {
                //To do: Log it to file
                return;
            }
            if(numberOfPlayers < 1 || numberOfPlayers > 23)
            {
                //To do: Log it to file
                return;
            }

            var players = new List<IPlayer>();
            //if number of players fall within the specifcation, go to the next step to assign cards to players
            DealerHelper.AssignCardsToPlayers(numberOfPlayers, players);
            //once assigned call dealer to find the winner(s)
            var winnerOrTiedWinners = DealerHelper.GetWinnerOrTiedWinners(players);
            //announce winner(s)
            Console.WriteLine("");
            Console.WriteLine(winnerOrTiedWinners);
            //Console.ReadLine();
        }

       
        

       

       


     


       

     
       

    }
}

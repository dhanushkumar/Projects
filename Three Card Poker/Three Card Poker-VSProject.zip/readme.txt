ReadMe

App will not work if the following conditions are met

2. If the number of players entered is not an integer
1. If the number of players are less than 0 or more than 23 (less than 24) 
3. Subsequent entries are not in the following format where 0 is the player identity, Qc 
   0 Qc Kc 4s


Pattern

Used Strategy pattern (partial) for different hands. 
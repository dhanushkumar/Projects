﻿
namespace Three_Card_Poker
{
    public class Hand : IHand
    {
        public Suit Suit { get ; set; }
        public Rank Rank { get; set ; }
    }
}

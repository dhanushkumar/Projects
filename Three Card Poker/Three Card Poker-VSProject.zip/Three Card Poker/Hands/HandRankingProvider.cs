﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Three_Card_Poker
//{
//    public class HandRankingProvider
//    {
       
//        private readonly IPlayer player;
//        private List<IHandStrategy> handRankStrategies = new List<IHandStrategy>();

//        public HandRankingProvider(IPlayer player)
//        {
//            this.player = player;
//            //handRankStrategies.Add(new HighCardStrategy(player));
//            //handRankStrategies.Add(new StraightFlushStrategy(player));
//            //handRankStrategies.Add(new ThreeOfAKindStrategy(player));
//            //handRankStrategies.Add(new StraightStrategy(player));
//            //handRankStrategies.Add(new FlushStrategy(player));
//            //handRankStrategies.Add(new PairStrategy(player));
          
//            //handRankStrategies = handRankStrategies.OrderBy(i => i.HandRanking).ToList();// sorted based on ranking

//        }

//        //public void  AssessHands()
//        //{
//        //   //foreach(var handRank in handRankStrategies)
//        //   // {
//        //   //     if(handRank.IsPlayerHand)
//        //   //     {
//        //   //         player.Result.HandRanking = handRank.HandRanking;
//        //   //         return;
//        //   //         //return player;
//        //   //     }
//        //   // }
//        //   // //return null;
//        //}

//        public void Rank()
//        {
//            var poker = new ThreeCardPoker(player);
           

//        }
//    }
//}
